#include "state.h"

State::~State()
{

}
