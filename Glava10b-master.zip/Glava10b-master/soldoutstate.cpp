#include "soldoutstate.h"

SoldOutState::SoldOutState(GumballMachine *gumballMachine)
{

}

SoldOutState::~SoldOutState()
{

}
